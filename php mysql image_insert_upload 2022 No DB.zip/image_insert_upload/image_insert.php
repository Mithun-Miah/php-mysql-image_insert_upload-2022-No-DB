<?php
// IMAGE UPLOAD PHP MySQL START CODE HERE
$connect = mysqli_connect('localhost', 'root', '', 'image');
// if($connect){
//     echo "DB Conn Successful";
// }else{
//     echo "DB Conn Failed";
// }

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $image_name = $_FILES['image']['name'];
    $tmp_name = $_FILES['image']['tmp_name'];
    
    $file_ext = explode(".", $image_name); // find only file extension name

    $file_check = strtolower(end($file_ext)); // cut only file extension name

    $valid_ext_name = array('png','jpg','jpeg'); // only allow those file extension name

    if(in_array($file_check, $valid_ext_name)){
        // check file size
        if($_FILES['image']['size'] < 2097152){ // 2 mb size allow
            // if file/image extension are correct then insert data permission here

            // Image Folder Location set code
        $upload = move_uploaded_file($tmp_name, "image_folder/".$image_name);

        if($upload){
            $insert = "INSERT INTO img_upload(name, phone, image)
            VALUES('$name', '$phone', '$image_name')";
            $query = mysqli_query($connect, $insert);
            if($query){
                echo "<script>alert('Data Send Success')</script>";
                // echo "Data Send Success";
            }else{
                echo "Data Send Failed";
            }
            
        }else{
            echo "Image Upload Failed";
        }

            
        }else{
            echo "<script>alert('check file size ! Only allow 2mb')</script>";

        }

    }else{
        echo "<script>alert('check file name ! Only allow png, jpg, jpeg file')</script>";
    }

}
// IMAGE UPLOAD PHP MySQL END CODE HERE
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <title>Image Upload CRUD Operations Project</title>
    <link rel="stylesheet" href="image_insert.css">
</head>

<body>
    <h2 class="title">Image Upload And Insert Data and Fetch Data / Read Data</h2>
    <div class="container">
        <form action="" enctype="multipart/form-data" method="POST">
            <input type="text" name="name" placeholder="Name"> <br><br>
            <input type="text" name="phone" placeholder="Phone"> <br><br>
            <input type="file" name="image"> <br><br>
            <button name="submit">Submit</button>
        </form>
        <hr>
        <h1>Fetch Data / Read Data</h1>
        <table>
            <th>Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Image</th>
            <th>Edit</th>
            <th>Delete</th>
            <tbody>
                <?php
                
                $select = "SELECT * FROM img_upload";
                $query = mysqli_query($connect, $select);

                while($row = mysqli_fetch_array($query)){ ?>

                <!-- while loop body -->

                <tr>
                    <td><?php echo $row['Id'] ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['phone'] ?></td>
                    <td><img src="image_folder/<?php echo $row['image'] ?>" height="100" width="100" alt=""></td>
                    <td><a href="edit.php?idNo=<?php echo $row['Id']; ?>">edit</a></td>
                    <td><a onclick="return confirm('Do You Want To Delete !')"
                            href="delete.php?idNo=<?php echo $row['Id']; ?>&image_pic=<?php echo $row['image']?>">delete</a>
                    </td>
                </tr>

                <?php }

                

                ?>
            </tbody>
        </table>

    </div>


</body>

</html>